-- DropIndex
DROP INDEX "MishikaLLM_DailyTagSpend_tag_key";

